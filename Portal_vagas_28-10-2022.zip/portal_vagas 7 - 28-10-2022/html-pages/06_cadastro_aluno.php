<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Cadastro Aluno</title>
</head>
<body>
    <header>
        <a href="./01_home.php"><img src="../img/logo_fatec.png" class="logo_fatec" id="topo"></a>

        <nav>
            <div class="dropdown">
                <button class="dropbtn-home">Cadastrar-se</button>

                <div class="dropdown-content content-sino btn-home">
                    <a href="./06_cadastro_aluno.php">Aluno</a>
                    <a href="./05_cadastro_empresa.php">Empresa</a>
                    <a href="./07_cadastro_fatec.php">Fatec</a>
                </div>
            </div>

            <div class="dropdown">
                <button class="dropbtn-home">Login</button>
                
                <div class="dropdown-content btn-home">
                    <a href="./03_login_aluno.php">Aluno</a>
                    <a href="./02_login_empresa.php">Empresa</a>
                    <a href="./04_login_fatec.php">Fatec</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="imagem_principal">
            <img src="../img/home-geral.jpg" class="imagem_topo">
        </section>
        
        <section class="container_principal">
            <div class="imagem_lateral">
                <h1 class="titulo_pagina">Cadastrar Aluno</h1>

                <div class="container_img_perfil">
                    <img src="../img/user.jpg" class="foto_pag_perfil">
                    <input type="file" class="arquivo_pag_perfil">
                </div>

                <div class="container_curriculo">
                    <h2 class="texto_curriculo">Adicionar currículo</h2>
                    <input type="file">
                </div>

                <div class="container_descricao">
                    <h2 class="texto_descricao">Adicionar breve descrição</h2>
                    <textarea name="descricao" id="descricao" cols="30" rows="30" class="area_descricao"></textarea>
                </div>

                <div class="btn_cadastro_editar">
                    <a href="#"><button type="button" class="btn_geral btn_cancelar">Cancelar</button></a>
                    <a href="#"><button type="button" class="btn_geral btn_salvar">Cadastrar</button></a>
                </div>
            </div>

            <div class="dados_perfil">

                <div class="card_perfil">
                    <h3 class="subtitulo">Informações Pessoais e Dados de Contato</h3>
                    
                    <form action="#" class="formulario">
                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="name">Nome</label>
                                <input type="text" name="name" id="name" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="sobrename">Sobrenome</label>
                                <input type="text" name="sobrename" id="sobrename" class="campo">
                            </div>
                        </div>

                        <br>

                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="cpf">CPF</label>
                                <input type="text" name="cpf" id="cpf" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="niver">Data de Nascimento</label>
                                <input type="date" name="niver" id="niver" class="campo">
                            </div>
                        </div>

                        <br>
                        
                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="tel">Telefone</label>
                                <input type="tel" name="tel" id="tel" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="cel">Celular</label>
                                <input type="tel" name="cel" id="cel" class="campo">
                            </div>
                        </div>

                        <br>

                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="email">E-mail</label>
                                <input type="email" name="email" id="email" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="cidade">Cidade</label>
                                <input type="text" name="cidade" id="cidade" class="campo">
                            </div>
                        </div>

                        <br>

                        <div class="sub_formulario">                            
                            <div class="sub_nome">
                                <label for="git">GitHub</label>
                                <input type="url" name="git" id="git" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="linkedin">LinkedIn</label>
                                <input type="url" name="linkedin" id="linkedin" class="campo">
                            </div>
                        </div>

                    </form>
                </div>

                <div class="card_perfil">
                    <h3 class="subtitulo">Informações Acadêmicas</h3>
                    
                    <form action="#" class="formulario">
                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="ra">RA</label>
                                <input type="text" name="ra" id="ra" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="curso">Curso</label>
                                <select name="curso" id="curso" class="campo">
                                    <option value="dsm">Desenvolvimento de Software Multiplataformas</option>
                                    <option value="gpi">Gestão da Produção Industrial</option>
                                    <option value="gti">Gestão da Tecnologia da Informação</option>
                                    <option value="ge">Gestão Empresarial</option>
                                </select>
                            </div>
                        </div>

                        <br>

                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="inicio">Data de início na Fatec</label>
                                <input type="date" name="inicio" id="inicio" class="campo">
                            </div>
                            <div class="sub_nome">
                                <label for="fim">Previsão de conclusão do curso</label>
                                <input type="date" name="fim" id="fim" class="campo">
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card_perfil">
                    <h3 class="subtitulo">Preferências</h3>
                    
                    <form action="#" class="formulario">
                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="modalidade">Tipo de Contrato</label><br><br>
                                <input type="checkbox" name="pj" value="pj">
                                <label for="modalidade">Contrato de Trabalho (PJ)</label><br>
                                <input type="checkbox" name="clt" value="clt">
                                <label for="modalidade">Contratação efetiva (CLT)</label><br>
                                <input type="checkbox" id="estagio-ferias" name="estagio-ferias" value="estagio-ferias">
                                <label for="estagio-ferias">Estágio de Férias</label><br>
                                <input type="checkbox" id="estagio-regular" name="estagio-regular" value="estagio-regular">
                                <label for="estagio-regular">Estágio Regular</label><br>
                                <input type="checkbox" id="freelance" name="freelance" value="freelance">
                                <label for="freelance">Projeto Pontual (Freelance)</label><br>
                                <input type="checkbox" id="trainee" name="trainee" value="trainee">
                                <label for="trainee">Trainee</label>
                            </div>

                            <div class="sub_nome">
                                <label for="modalidade">Modalidade de trabalho</label><br><br>
                                <input type="checkbox" name="hibrido" value="hibrido">
                                <label for="modalidade">Híbrida</label><br>
                                <input type="checkbox" name="home-office" value="home-office">
                                <label for="modalidade">Home-office</label><br>
                                <input type="checkbox" name="presencial" value="presencial">
                                <label for="modalidade">Presencial</label>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card_perfil">
                    <h3 class="subtitulo">Habilidades Técnicas</h3>
                    
                    <form action="#" class="formulario">
                        <div class="sub_formulario">
                            <div class="sub_nome">
                                <label for="linguagens">Linguagens</label><br><br>
                                <input type="checkbox" name="c" value="c">
                                <label for="linguagens">C</label><br>
                                <input type="checkbox" name="c#" value="c#">
                                <label for="linguagens">C#</label><br>
                                <input type="checkbox" name="c++" value="c++">
                                <label for="linguagens">C++</label><br>
                                <input type="checkbox" name="css" value="css">
                                <label for="linguagens">CSS</label><br>
                                <input type="checkbox" name="html" value="html">
                                <label for="linguagens">HTML</label><br>
                                <input type="checkbox" name="java" value="java">
                                <label for="linguagens">Java</label><br>
                                <input type="checkbox" name="javascript" value="javascript">
                                <label for="linguagens">JavaScript</label><br>
                                <input type="checkbox" name="php" value="php">
                                <label for="linguagens">PHP</label><br>
                                <input type="checkbox" name="python" value="python">
                                <label for="linguagens">Python</label><br>
                                <input type="checkbox" name="ruby" value="ruby">
                                <label for="linguagens">Ruby</label><br>
                                <input type="checkbox" name="sql" value="sql">
                                <label for="linguagens">SQL</label>
                            </div>

                            <div class="sub_nome">
                                <label for="habilidades">Softwares e Plataformas</label><br><br>
                                <input type="checkbox" name="amazon" value="amazon">
                                <label for="habilidades">Amazon AWS</label><br>
                                <input type="checkbox" name="cad" value="cad">
                                <label for="habilidades">AutoCad</label><br>
                                <input type="checkbox" name="excel" value="excel">
                                <label for="habilidades">Excel</label><br>
                                <input type="checkbox" name="github" value="github">
                                <label for="habilidades">GitHub</label><br>
                                <input type="checkbox" name="jira" value="jira">
                                <label for="habilidades">Jira</label><br>
                                <input type="checkbox" name="powerbi" value="powerbi">
                                <label for="habilidades">Power BI</label><br>
                                <input type="checkbox" name="powerpoint" value="powerpoint">
                                <label for="habilidades">Power Point</label><br>
                                <input type="checkbox" name="trello" value="trello">
                                <label for="habilidades">Trello</label><br>
                                <input type="checkbox" name="vscode" value="vscode">
                                <label for="habilidades">Visual Studio Code</label><br>
                                <input type="checkbox" name="word" value="word">
                                <label for="habilidades">Word</label><br>
                                <input type="checkbox" name="wordpress" value="wordpress">
                                <label for="habilidades">WordPress</label>
                            </div>

                            <div class="sub_nome">
                                <label for="linguagens">Idiomas</label><br><br>
                                <input type="checkbox" name="alemao" value="alemao">
                                <label for="linguagens">Alemão</label><br>
                                <input type="checkbox" name="arabe" value="arabe">
                                <label for="linguagens">Árabe</label><br>
                                <input type="checkbox" name="espanhol" value="espanhol">
                                <label for="linguagens">Espanhol</label><br>
                                <input type="checkbox" name="frances" value="frances">
                                <label for="linguagens">Francês</label><br>
                                <input type="checkbox" name="hebraico" value="hebraico">
                                <label for="linguagens">Hebraico</label><br>
                                <input type="checkbox" name="ingles" value="ingles">
                                <label for="linguagens">Inglês</label><br>                               
                                <input type="checkbox" name="italiano" value="italiano">
                                <label for="linguagens">Italiano</label><br>
                                <input type="checkbox" name="japones" value="japones">
                                <label for="linguagens">Japonês</label><br>
                                <input type="checkbox" name="mandarim" value="mandarim">
                                <label for="linguagens">Mandarim</label><br>
                                <input type="checkbox" name="portugues" value="portugues">
                                <label for="linguagens">Português</label><br>
                                <input type="checkbox" name="russo" value="russo">
                                <label for="linguagens">Russo</label>
                            </div>                            
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="texto_footer">
            <h3>Dúvidas ou Sugestões? Converse com a gente!</h3>
        </div>

        <div class="info_contatos">
            <p>contato@fatecitapira.edu.br</p>
            <p>(19) 3843-1996</p>
            <p><a href="https://www.fatecitapira.edu.br/" target="_blank">www.fatecitapira.edu.br</a></p>
        </div>

        <div class="icones_footer">
            <a href="https://www.instagram.com/accounts/login/?next=/fatecdeitapira/" target="_blank"><img src="../img/icones/instagram.png" class="icon_footer"></a>
            <a href="https://pt-br.facebook.com/fatecitapira/" target="_blank"><img src="../img/icones/facebook.png" class="icon_footer"></a>
            <a href="https://api.whatsapp.com/send?phone=551938635210" target="_blank"><img src="../img/icones/whatsapp.png" class="icon_footer"></a>

        </div>

        <a href="#topo" class="backtotop">
            <img src="../img/icones/foguete.png" class="foguete">
            <p>Voltar ao topo</p>
        </a>
    </footer>
</body>
</html>