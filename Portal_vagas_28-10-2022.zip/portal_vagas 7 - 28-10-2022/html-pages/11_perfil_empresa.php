<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Meu Perfil</title>
</head>
<body>
    <header>
        <a href="./11_perfil_empresa.php"><img src="../img/logo_fatec.png" class="logo_fatec" id="topo"></a>
        <nav>
            <div class="dropdown">
                <button class="dropbtn">
                    <img src="../img/icones/sino.png" class="header_icone">
                </button>

                <div class="dropdown-content content-sino">
                    <a href="./14_painel_vagas_empresa.php">Acompanhe suas vagas</a>
                    <a href="./17_tela_vaga_empresa.php">Nova candidatura na sua vaga</a>
                    <a href="./08_alterar_perfil_empresa.php">Atualize seu perfil</a>
                </div>
            </div>

            <div class="dropdown">
                <button class="dropbtn">
                    <img src="../img/icones/menu.png" class="header_icone">
                </button>
                
                <div class="dropdown-content">
                    <a href="./14_painel_vagas_empresa.php">Minhas Vagas</a>
                    <a href="./20_cadastrar_vaga_empresa.php">Cadastrar Vaga</a>
                    <a href="./08_alterar_perfil_empresa.php">Alterar Perfil</a>
                    <a href="./01_home.php">Sair</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="imagem_principal">
            <img src="../img/home-empresa.jpg" class="imagem_topo">
        </section>

        <section class="resumo_perfil">
            <p class="nome_perfil">Olá, Camaleon!</p>
            
            <div class="info_perfil">
                <div class="container_foto">
                    <img src="../img/usuario_empresa.png" class="foto_perfil">
                    <a href="./09_alterar_perfil_aluno.php" class="editar_perfil">Editar Perfil</a>
                </div>

                <div class="area_info_card">
                    <div class="info_card">
                        <img src="../img/icones/dinheiro.png" class="icone_info_card">
                        <h3 class="titulo_info_card">Faixa Salarial</h3>
                        <p class="texto_info_card">É importante que você informe a faixa salarial correspondente à vaga que está anunciando ou se este ponto será negociado posteriormente entre a empresa e o candidato</p>
                        <a href="./20_cadastrar_vaga_empresa.php" class="link_info_card">Cadastre nova vaga!</a>
                    </div>

                    <div class="info_card">
                        <img src="../img/icones/pin.png" class="icone_info_card">
                        <h3 class="titulo_info_card">Modalidade de Trabalho</h3>
                        <p class="texto_info_card">É importante que você informe ao candidato o tipo de modalidade (presencial, home-office ou híbrido) que atualmente consegue se enquadrar na sua realidade</p>
                        <a href="./20_cadastrar_vaga_empresa.php" class="link_info_card">Cadastre nova vaga!</a>
                    </div>

                    <div class="info_card">
                        <img src="../img/icones/pasta.png" class="icone_info_card">
                        <h3 class="titulo_info_card">Área das Vagas</h3>
                        <p class="texto_info_card">É importante que você informe qual a área correspondente à vaga anunciada (Comercial, Gestão, Administrativo, Tecnologia da Informação)</p>
                        <a href="./20_cadastrar_vaga_empresa.php" class="link_info_card">Cadastre nova vaga!</a>
                    </div>
                    <div class="info_card">
                        <img src="../img/icones/chapeuformatura.png" class="icone_info_card">
                        <h3 class="titulo_info_card">Requsitos da Vaga</h3>
                        <p class="texto_info_card">Adicione os requisitos mínimos para o preenchimento da vaga (formação, cursos, ferramentas, softwares, softskills). Também é interessante acrescentar quais são os possíveis diferenciais</p>
                        <a href="./20_cadastrar_vaga_empresa.php" class="link_info_card">Cadastre nova vaga!</a>
                    </div>
                </div>
            </div>

        </section>

        <h2 class="texto_mini_painel">Acompanhe de perto! Essas são suas últimas vagas cadastradas</h2>

        <section class="mini_painel">
            <div class="area_cards">

                <div class="card_vaga">
                    <div class="head_card_vaga">
                        <h3 class="titulo_card_vaga">Estágio de Férias</h3>
                        <p class="area_card_vaga">Área: Gestão</p>
                    </div>
                    <div class="body_card_vaga">
                        <div class="info_card_vaga">
                            <img src="../img/icones/pin.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Híbrida</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/bandeira.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Itapira-SP</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/pasta.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Estágio integral</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/bolsadinheiro.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">R$ 1.000,00 a R$ 1.500,00</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/calendario.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">até 30/11/2022</p>
                        </div>
                        <a href="./17_tela_vaga_empresa.php" class="link_vaga">+ informações</a>
                    </div>
                </div>

                <div class="card_vaga">
                    <div class="head_card_vaga">
                        <h3 class="titulo_card_vaga">Estágio de Férias</h3>
                        <p class="area_card_vaga">Área: Gestão</p>
                    </div>
                    <div class="body_card_vaga">
                        <div class="info_card_vaga">
                            <img src="../img/icones/pin.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Híbrida</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/bandeira.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Itapira-SP</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/pasta.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Estágio integral</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/bolsadinheiro.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">R$ 1.000,00 a R$ 1.500,00</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/calendario.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">até 30/11/2022</p>
                        </div>
                        <a href="./17_tela_vaga_empresa.php" class="link_vaga">+ informações</a>
                    </div>
                </div>

                <div class="card_vaga">
                    <div class="head_card_vaga">
                        <h3 class="titulo_card_vaga">Estágio de Férias</h3>
                        <p class="area_card_vaga">Área: Gestão</p>
                    </div>
                    <div class="body_card_vaga">
                        <div class="info_card_vaga">
                            <img src="../img/icones/pin.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Híbrida</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/bandeira.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Itapira-SP</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/pasta.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">Estágio integral</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/bolsadinheiro.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">R$ 1.000,00 a R$ 1.500,00</p>
                        </div>
                        <div class="info_card_vaga">
                            <img src="../img/icones/calendario.png" class="icone_card_vaga">
                            <p class="descricaco_card_vaga">até 30/11/2022</p>
                        </div>
                        <a href="./17_tela_vaga_empresa.php" class="link_vaga">+ informações</a>
                    </div>
                </div>

            </div>
            
            <a href="./14_painel_vagas_empresa.php" class="link_painel_vagas">ver mais vagas</a>
        </section>
    </main>

    <footer>
        <div class="texto_footer">
            <h3>Dúvidas ou Sugestões? Converse com a gente!</h3>
        </div>

        <div class="info_contatos">
            <p>contato@fatecitapira.edu.br</p>
            <p>(19) 3843-1996</p>
            <p><a href="https://www.fatecitapira.edu.br/" target="_blank">www.fatecitapira.edu.br</a></p>
        </div>

        <div class="icones_footer">
            <a href="https://www.instagram.com/accounts/login/?next=/fatecdeitapira/" target="_blank"><img src="../img/icones/instagram.png" class="icon_footer"></a>
            <a href="https://pt-br.facebook.com/fatecitapira/" target="_blank"><img src="../img/icones/facebook.png" class="icon_footer"></a>
            <a href="https://api.whatsapp.com/send?phone=551938635210" target="_blank"><img src="../img/icones/whatsapp.png" class="icon_footer"></a>

        </div>

        <a href="#topo" class="backtotop">
            <img src="../img/icones/foguete.png" class="foguete">
            <p>Voltar ao topo</p>
        </a>
    </footer>
</body>
</html>