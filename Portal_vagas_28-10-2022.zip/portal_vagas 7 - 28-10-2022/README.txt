Versão 7 contém:

Arquivar, Deletar, Alterar, Cadastrar Vaga
Painel de vagas do aluno e da empresa já estão funcionais (falta Fatec)
Tela da vaga do aluno e da empresa já estão funcionais (falta Fatec)
Minhas Candidaturas do aluno já está funcional
Visualizar perfil do aluno sendo empresa está ok (falta Fatec)

FALTA
Cadastros (Todos)
Alterar dados cadastrados (Todos)
Login (Todos)
Visualizar perfil empresa (Aluno e Fatec)
Visualizar perfil aluno (Fatec)
Painel de vagas (Fatec)
Solicitações para aprovação (Fatec)
Alunos e empresas cadastradas (Fatec)
Tela da vaga (Fatec)
Tela inicial de perfil (Todos)
Fazer a Home
Cadastrar e puxar imagens e arquivos
