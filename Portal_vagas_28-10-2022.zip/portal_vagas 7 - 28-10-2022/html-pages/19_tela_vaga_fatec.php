<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Informações da Vaga</title>
</head>
<body>
    <header>
        <a href="./13_perfil_fatec.php"><img src="../img/logo_fatec.png" class="logo_fatec" id="topo"></a>
        <nav>
            <div class="dropdown">
                <button class="dropbtn">
                    <img src="../img/icones/sino.png" class="header_icone">
                </button>

                <div class="dropdown-content content-sino">
                    <a href="./16_painel_vagas_fatec.php">Nova vaga cadastrada!</a>
                    <a href="./28_solicitacao_aprovacao_fatec.php">Nova solicitação pendente</a>
                    <a href="./10_alterar_perfil_fatec.php">Atualize seu perfil</a>
                </div>
            </div>

            <div class="dropdown">
                <button class="dropbtn">
                    <img src="../img/icones/menu.png" class="header_icone">
                </button>
                
                <div class="dropdown-content">
                    <a href="./16_painel_vagas_fatec.php">Painel de Vagas</a>
                    <a href="./27_empresas_cadastradas_fatec.php">Empresas Cadastradas</a>
                    <a href="./26_alunos_cadastrados_fatec.php">Alunos Cadastrados</a>
                    <a href="./28_solicitacao_aprovacao_fatec.php">Solicitações Pendentes</a>
                    <a href="./30_relatorio_gerencial_fatec.php">Relatório Gerencial</a>
                    <a href="./10_alterar_perfil_fatec.php">Alterar Perfil</a>
                    <a href="./01_home.php">Sair</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="imagem_principal">
            <img src="../img/home-fatec.jpg" class="imagem_topo">
        </section>

        <section class="container_titulo_vaga">
            <div class="texto_titulo_vaga">
                <h1 class="titulo_vaga">Estágio de Férias</h1>
                <h2 class="tipo_vaga">Área: Gestão Empresarial</h2>
            </div>
            <img src="../img/icones/mesa.png" class="icone_mesa">
        </section>

        <section class="container_descricao_vaga">
            <div class="container_info_gerais">
                <div class="info_gerais_lados">
                    <div class="info_gerais_linha">
                        <img src="../img/icones/pin.png" class="icone_tela_vaga">
                        <h3 class="texto_icone">Híbrida</h3>
                    </div>

                    <div class="info_gerais_linha">
                        <img src="../img/icones/bandeira.png" class="icone_tela_vaga">
                        <h3 class="texto_icone">Itapira-SP</h3>
                    </div>
                    
                    <div class="info_gerais_linha">
                        <img src="../img/icones/pasta.png" class="icone_tela_vaga">
                        <h3 class="texto_icone">Estágio de Férias</h3>
                    </div>
                </div>

                <div class="info_gerais_lados">
                    <div class="info_gerais_linha">
                        <img src="../img/icones/bolsadinheiro.png" class="icone_tela_vaga">
                        <h3 class="texto_icone">R$ 1.0000 a R$ 1.500,00</h3>
                    </div>

                    <div class="info_gerais_linha">
                        <img src="../img/icones/relogio.png" class="icone_tela_vaga">
                        <h3 class="texto_icone">6h diárias</h3>
                    </div>
                    
                    <div class="info_gerais_linha">
                        <img src="../img/icones/calendario.png" class="icone_tela_vaga">
                        <h3 class="texto_icone">até 30/11/2022</h3>
                    </div>
                </div>
            </div>

            <div class="descricao_vaga">
                <h2 class="topico_vaga"><strong>Empresa Contratante</strong></h2>
                <p class="texto_vaga"><a href="./25_visualizar_perfil_empresa_fatec.php">Camaleon</a></p>
            </div>

            <div class="descricao_vaga">
                <h2 class="topico_vaga"><strong>Descrição da Vaga</strong></h2>
                <p class="texto_vaga">Regime de contratação do tipo Estágio, com jornada parcial no período da manhã. O estagiário terá a oportunidade de participar de projetos de site e plataformas online. Além disso, irá compor uma equipe jovem e dinâmica, com espírito de grupo com alto nível de compartilhamento de conhecimentos e comprometimento com resultados!</p>
            </div>

            <div class="descricao_vaga">
                <h2 class="topico_vaga"><strong>Requisitos da Vaga</strong></h2>
                <ul>
                    <li class="texto_vaga">HTML</li>
                    <li class="texto_vaga">CSS</li>
                    <li class="texto_vaga">JavaScript</li>
                </ul>
            </div>

            <div class="descricao_vaga">
                <h2 class="topico_vaga"><strong>Diferenciais da Vaga</strong></h2>
                <ul>
                    <li class="texto_vaga">PHP</li>
                    <li class="texto_vaga">React JS</li>
                    <li class="texto_vaga">TypeScript</li>
                </ul>
            </div>

            <div class="btn_vagas">
                <a href="#"><button type="button" class="btn_pag_vaga arquivar">Arquivar Vaga</button></a>
                <a href="#"><button type="button" class="btn_pag_vaga excluir">Excluir Vaga</button></a>
                <a href="#"><button type="button" class="btn_pag_vaga marcar_fatec">Vaga preenchida com aluno Fatec</button></a>
            </div>
        </section>

        <h1 class="titulo_candidatos">Candidatos a vaga</h1>

        <section class="container_candidatos">
            
            <a href="./23_visualizar_perfil_aluno_fatec.php" class="candidato_vaga">
                <img src="../img/usuario_estudante.jpg" class="foto_candidato">
                <p class="nome_candidato"><strong>Pedro Paulo Cardoso</strong></p>
            </a>
            <a href="/23_visualizar_perfil_aluno_fatec.php" class="candidato_vaga">
                <img src="../img/1.jpg" class="foto_candidato">
                <p class="nome_candidato"><strong>Jéssica de Cássia Martins</strong></p>
            </a>
            <a href="/23_visualizar_perfil_aluno_fatec.php" class="candidato_vaga">
                <img src="../img/2.jpg" class="foto_candidato">
                <p class="nome_candidato"><strong>Paula Raquel Lima</strong></p>
            </a>
            <a href="/23_visualizar_perfil_aluno_fatec.php" class="candidato_vaga">
                <img src="../img/3.jpg" class="foto_candidato">
                <p class="nome_candidato"><strong>Clóvis Silva</strong></p>
            </a>
            <a href="/23_visualizar_perfil_aluno_fatec.php" class="candidato_vaga">
                <img src="../img/4.jpg" class="foto_candidato">
                <p class="nome_candidato"><strong>Gustavo Ecasulayo</strong></p>
            </a>
            <a href="/23_visualizar_perfil_aluno_fatec.php" class="candidato_vaga">
                <img src="../img/5.jpg" class="foto_candidato">
                <p class="nome_candidato"><strong>Patricia Fuggire</strong></p>
            </a>            
        </section>
    </main>

    <footer>
        <div class="texto_footer">
            <h3>Dúvidas ou Sugestões? Converse com a gente!</h3>
        </div>

        <div class="info_contatos">
            <p>contato@fatecitapira.edu.br</p>
            <p>(19) 3843-1996</p>
            <p><a href="https://www.fatecitapira.edu.br/" target="_blank">www.fatecitapira.edu.br</a></p>
        </div>

        <div class="icones_footer">
            <a href="https://www.instagram.com/accounts/login/?next=/fatecdeitapira/" target="_blank"><img src="../img/icones/instagram.png" class="icon_footer"></a>
            <a href="https://pt-br.facebook.com/fatecitapira/" target="_blank"><img src="../img/icones/facebook.png" class="icon_footer"></a>
            <a href="https://api.whatsapp.com/send?phone=551938635210" target="_blank"><img src="../img/icones/whatsapp.png" class="icon_footer"></a>

        </div>

        <a href="#topo" class="backtotop">
            <img src="../img/icones/foguete.png" class="foguete">
            <p>Voltar ao topo</p>
        </a>
    </footer>
</body>
</html>